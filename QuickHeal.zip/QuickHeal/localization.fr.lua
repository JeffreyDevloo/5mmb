if (GetLocale() == "frFR") then

-- Shaman
QUICKHEAL_SPELL_LESSER_HEALING_WAVE = 'Vague de soins inf\195\169rieurs';
QUICKHEAL_SPELL_HEALING_WAVE = 'Vague de soins';

-- Priest
QUICKHEAL_SPELL_LESSER_HEAL = 'Soins inf\195\169rieurs';
QUICKHEAL_SPELL_HEAL = 'Soins';
QUICKHEAL_SPELL_GREATER_HEAL = 'Soins sup\195\169rieurs';
QUICKHEAL_SPELL_FLASH_HEAL = 'Soins rapides';

-- Paladin
QUICKHEAL_SPELL_HOLY_LIGHT = 'Lumi\195\168re sacr\195\169e';
QUICKHEAL_SPELL_FLASH_OF_LIGHT = 'Eclair lumineux';

-- Druid
QUICKHEAL_SPELL_HEALING_TOUCH = 'Toucher gu\195\169risseur';
QUICKHEAL_SPELL_REGROWTH = 'R\195\169tablissement';

end